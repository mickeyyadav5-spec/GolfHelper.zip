Yahan club ki PNG rakho. File ka naam: club ke naam ke sirf lowercase letters/digits + .png
Jaise: theapocalypse.png , thequarterback.png
Naam list ke liye data/club_image_names.txt dekho.
