package com.golfhelper.app

import java.util.Locale
import kotlin.math.abs

fun f0(d: Double): String = String.format(Locale.US, "%.0f", d)
fun f1(d: Double): String = String.format(Locale.US, "%.1f", d)
fun sgn(d: Double): String = (if (d >= 0) "+" else "") + f1(d)
fun sgnI(i: Int): String = (if (i >= 0) "+" else "") + i
fun sideTxt(o: Double): String =
    if (o < -0.05) "L ${f1(abs(o))}" else if (o > 0.05) "R ${f1(abs(o))}" else "CENTER"

/** Live values shared between the panel and the overlay windows. */
object AppState {
    var ballName = ""
    var clubName = ""
    var catIdx = 0
    var dist = 150
    var elev = 0
    var wind = 0
    var windDeg = 0
    /** 0 = Auto (from distance), 1 = Min, 2 = Mid, 3 = Max, 4 = Manual % */
    var mode = 3
    var manualPct = 90
    var guideBallName = ""
    var guideAllLevels = false
    var notePage = 0
    var guideText = ""
    var guideOut = ""
}

object Calc {
    class Result(
        val cross: Double,
        val along: Double,
        val plays: Double,
        val offset: Double,
        val frac: Double,
        val reach: Double,
        val max: Double,
        val mid: Double,
        val min: Double,
        val needPct: Double,
        val elevYd: Double,
        val elevPct: Double,
        val windMul: Double,
        val status: Int
    )

    /** extra distance multiplier a ball gives (basic ball = 1.0) */
    fun ballFactor(b: Ball): Double = 1.0 + b.power * Store.p.ballPowerPct / 100.0

    /** how much of the wind still reaches the ball (basic ball = 1.0) */
    fun windMul(b: Ball): Double = (1.0 - b.wind * Store.p.windPerPt).coerceAtLeast(0.2)

    fun maxDist(c: Club, b: Ball, level: Int): Double = c.pw(level) * ballFactor(b)

    /** returns Triple(min, mid, max) yards */
    fun range(c: Club, b: Ball, level: Int): Triple<Double, Double, Double> {
        val mx = maxDist(c, b, level)
        return Triple(mx * Store.p.minPct / 100.0, mx * Store.p.midPct / 100.0, mx)
    }

    /**
     * wind direction: 0 = arrow points up (tailwind), 90 = points right, 180 = headwind, 270 = points left.
     * offset: negative = aim LEFT, positive = aim RIGHT (in grid squares).
     */
    fun compute(
        c: Club, b: Ball, level: Int, mode: Int, manualPct: Int,
        dist: Double, elev: Double, wind: Double, deg: Double
    ): Result {
        val s = Store.p
        val rad = Math.toRadians(deg)
        val cross = wind * Math.sin(rad)
        val along = wind * Math.cos(rad)
        val r = range(c, b, level)
        val elevYd = elev * s.elevF
        val plays = dist + elevYd - along * s.headF
        val needFrac = if (r.third > 0) plays / r.third else 1.0
        val frac = when (mode) {
            1 -> s.minPct / 100.0
            2 -> s.midPct / 100.0
            3 -> 1.0
            4 -> manualPct / 100.0
            else -> needFrac
        }.coerceIn(0.2, 1.2)
        val wm = windMul(b)
        val off = -cross * s.windBase * Store.catRatio(c.cat) * wm * frac
        val status = if (mode == 0) {
            if (needFrac > 1.0) 1 else if (needFrac < 0.4) -1 else 0
        } else 0
        val elevPct = if (r.third > 0) elevYd / r.third * 100.0 else 0.0
        return Result(cross, along, plays, off, frac, r.third * frac, r.third, r.second, r.first, needFrac * 100.0, elevYd, elevPct, wm, status)
    }

    /** the user's own clubs (at their saved level) that can reach the distance, best fit first */
    fun suggest(plays: Double, b: Ball): List<Club> {
        val ok = Store.clubs.filter {
            val r = range(it, b, Store.levelOf(it))
            plays >= r.first && plays <= r.third
        }
        return ok.sortedBy { abs(plays - range(it, b, Store.levelOf(it)).second) }.take(3)
    }

    fun findClub(q: String): Club? {
        val n = q.trim().lowercase().removePrefix("the ").trim()
        if (n.isEmpty()) return null
        return Store.clubs.firstOrNull { it.name.lowercase().removePrefix("the ") == n }
            ?: Store.clubs.firstOrNull { it.name.lowercase().contains(n) }
    }

    /**
     * Converts a guide written for the reference ball into guides for the other balls.
     * Each line: club,wind,offset[,elevation[,level]]    offset: + = aim right, - = aim left
     */
    fun convert(text: String, ref: Ball, allLevels: Boolean, targets: List<Ball>): String {
        val sb = StringBuilder()
        val s = Store.p
        var n = 0
        for (raw in text.lines()) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            val parts = line.split(",").map { it.trim() }
            if (parts.size < 3) {
                sb.append("? $line\n  format: club,wind,offset,elev,level\n\n")
                continue
            }
            val club = findClub(parts[0])
            if (club == null) {
                sb.append("? club nahi mila: ${parts[0]}\n\n")
                continue
            }
            val wind = parts[1].toDoubleOrNull()
            val off = parts[2].replace("+", "").toDoubleOrNull()
            val elev = if (parts.size > 3) (parts[3].replace("+", "").toDoubleOrNull() ?: 0.0) else 0.0
            val lvRef = if (parts.size > 4) (parts[4].toIntOrNull() ?: Store.levelOf(club)) else Store.levelOf(club)
            if (wind == null || off == null) {
                sb.append("? number galat: $line\n\n")
                continue
            }
            n++
            val elevYd = elev * s.elevF
            val refMax = maxDist(club, ref, lvRef)
            sb.append("${club.name} | wind ${f1(wind)} | elev ${sgn(elev)} (${sgn(elevYd)} yd)\n")
            sb.append("  guide: ${ref.name}, Lv$lvRef, aim ${sideTxt(off)}\n")
            val ordered = ArrayList<Ball>()
            ordered.add(ref)
            for (t in targets) if (t !== ref) ordered.add(t)
            for (t in ordered) {
                val levelsToShow: List<Int> = if (allLevels) (1..club.levels).toList() else listOf(lvRef)
                for (l in levelsToShow) {
                    val tMax = maxDist(club, t, l)
                    val ratio = if (tMax > 0) refMax / tMax else 1.0
                    val o = off * (windMul(t) / windMul(ref)) * ratio
                    val r = range(club, t, l)
                    val ep = if (r.third > 0) elevYd / r.third * 100.0 else 0.0
                    val mark = if (t === ref && l == lvRef) "*" else "-"
                    sb.append(" $mark ${t.name} Lv$l: aim ${sideTxt(o)} | min ${f0(r.first)} mid ${f0(r.second)} max ${f0(r.third)} yd | elev ${sgn(elevYd)} yd (${sgn(ep)}% power)\n")
                }
            }
            sb.append("\n")
        }
        if (n == 0 && sb.isEmpty()) sb.append("Koi line nahi mili.")
        return sb.toString()
    }

    /** one-line summary used by the notebook */
    fun setupLine(): String {
        val a = AppState
        val c = Store.curClub()
        val b = Store.curBall()
        val lv = Store.levelOf(c)
        val r = compute(c, b, lv, a.mode, a.manualPct, a.dist.toDouble(), a.elev.toDouble(), a.wind.toDouble(), a.windDeg.toDouble())
        val pm = when (a.mode) {
            1 -> "Min"
            2 -> "Mid"
            3 -> "Max"
            4 -> "${a.manualPct}%"
            else -> "Auto"
        }
        return "▶ ${c.name} Lv$lv | ${b.name} | ${a.dist}yd | elev ${sgnI(a.elev)} | wind ${a.wind}@${a.windDeg}° | power $pm ${f0(r.frac * 100)}% | aim ${sideTxt(r.offset)}"
    }
}
