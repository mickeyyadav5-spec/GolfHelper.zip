package com.golfhelper.app

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

/** One club. Every array holds one value per level (index 0 = level 1). */
class Club(
    val name: String,
    val cat: String,
    val power: IntArray,
    val acc: IntArray,
    val top: IntArray,
    val back: IntArray,
    val curl: IntArray,
    val guide: DoubleArray
) {
    val levels: Int get() = power.size

    fun lv(l: Int): Int = (l - 1).coerceIn(0, (levels - 1).coerceAtLeast(0))
    fun pw(l: Int): Int = if (power.isEmpty()) 0 else power[lv(l)]
    private fun at(a: IntArray, l: Int): Int = if (a.isEmpty()) 0 else a[(l - 1).coerceIn(0, a.size - 1)]
    fun accAt(l: Int) = at(acc, l)
    fun topAt(l: Int) = at(top, l)
    fun backAt(l: Int) = at(back, l)
    fun curlAt(l: Int) = at(curl, l)
    fun guideAt(l: Int): Double = if (guide.isEmpty()) 0.0 else guide[(l - 1).coerceIn(0, guide.size - 1)]
}

/** One ball. power / side / wind are on the game's 0-10 scale. */
class Ball(
    val name: String,
    val gen: String,
    val power: Int,
    val side: Int,
    val wind: Int,
    val top: Int,
    val back: Int,
    val prec: Int,
    val needle: String
)

class Note(var body: String)

class Prefs {
    // calibration
    var ballPowerPct = 0.5   // % extra distance per 1 point of ball power
    var windPerPt = 0.05     // wind reduction per 1 point of ball wind resistance (10 pts = 50%)
    var windBase = 0.55      // grid squares of aim per 1 mph crosswind (driver, full power)
    var elevF = 1.0          // yards per 1 elevation unit
    var headF = 1.0          // yards per 1 mph head/tail wind
    var minPct = 70.0        // "Min" power as % of max
    var midPct = 85.0        // "Mid" power as % of max
    var autoNote = false
    // grid / lens / bubble
    var gridOn = true
    var centerLine = true
    var markerOn = true
    var gridSize = 60
    var gridThick = 2
    var gridAlpha = 150
    var gridColor = Color.WHITE
    var hudOn = true          // floating wind box (lens + direction + number)
    var hudPad = true         // 8-arrow direction pad in the wind box
    var hudSize = 130         // lens diameter in dp
    var hudX = 0
    var hudY = -1             // -1 = place near the game's wind arrow on first run
    var panelSize = 0         // 0 small, 1 medium, 2 large
    var gridStyle = 1         // 0 squares, 1 rings + ticks
    var gridCx = 50           // grid centre, % of screen width
    var gridCy = 62           // grid centre, % of screen height
    var bubbleX = 10
    var bubbleY = 200
}

object Store {
    private lateinit var sp: SharedPreferences
    var clubs: List<Club> = emptyList()
    var balls: List<Ball> = emptyList()
    var notes = mutableListOf<Note>()
    val favs = LinkedHashSet<String>()
    val levels = HashMap<String, Int>()
    val p = Prefs()
    private var ready = false

    val catKeys = listOf("driver", "wood", "longiron", "shortiron", "wedge", "rough", "sand")
    val catNames = listOf("Driver", "Wood", "Long Iron", "Short Iron", "Wedge", "Rough Iron", "Sand Wedge")

    /** icon shape used by ClubIconView */
    fun iconType(cat: String): String = when (cat) {
        "driver" -> "driver"
        "wood" -> "wood"
        "longiron", "shortiron", "rough" -> "iron"
        "wedge", "sand" -> "wedge"
        else -> "putter"
    }

    /** how strongly wind pushes a shot from this kind of club (driver = 1.0) */
    fun catRatio(cat: String): Double = when (cat) {
        "driver" -> 1.0
        "wood" -> 0.9
        "longiron" -> 0.82
        "shortiron" -> 0.64
        "rough" -> 0.64
        "wedge" -> 0.55
        "sand" -> 0.55
        else -> 0.18
    }

    /** distinct colour per club (stable, from the name) */
    fun clubColor(name: String): Int {
        val h = ((name.hashCode() % 360) + 360) % 360
        return Color.HSVToColor(floatArrayOf(h.toFloat(), 0.55f, 0.95f))
    }

    fun clubSlug(name: String): String = name.lowercase().filter { it.isLetterOrDigit() }

    private val bmpCache = HashMap<String, android.graphics.Bitmap?>()

    /** optional real picture: put PNGs in assets/clubimg/<slug>.png (slug = name, lowercase letters/digits only) */
    fun clubBitmap(ctx: Context, name: String): android.graphics.Bitmap? {
        val k = clubSlug(name)
        if (bmpCache.containsKey(k)) return bmpCache[k]
        val b = try {
            ctx.assets.open("clubimg/$k.png").use { android.graphics.BitmapFactory.decodeStream(it) }
        } catch (e: Exception) {
            null
        }
        bmpCache[k] = b
        return b
    }

    private fun ints(a: JSONArray) = IntArray(a.length()) { a.getInt(it) }
    private fun dbls(a: JSONArray) = DoubleArray(a.length()) { a.getDouble(it) }
    private fun readAsset(ctx: Context, n: String): String =
        ctx.assets.open(n).bufferedReader(Charsets.UTF_8).use { it.readText() }

    fun init(ctx: Context) {
        if (ready) return
        sp = ctx.applicationContext.getSharedPreferences("golfhelper", Context.MODE_PRIVATE)
        val cj = JSONArray(readAsset(ctx, "clubs.json"))
        val cl = ArrayList<Club>()
        for (i in 0 until cj.length()) {
            val o = cj.getJSONObject(i)
            cl.add(
                Club(
                    o.getString("n"), o.getString("c"), ints(o.getJSONArray("p")), ints(o.getJSONArray("a")),
                    ints(o.getJSONArray("t")), ints(o.getJSONArray("b")), ints(o.getJSONArray("cu")),
                    dbls(o.getJSONArray("g"))
                )
            )
        }
        clubs = cl
        val bj = JSONArray(readAsset(ctx, "balls.json"))
        val bl = ArrayList<Ball>()
        for (i in 0 until bj.length()) {
            val o = bj.getJSONObject(i)
            bl.add(
                Ball(
                    o.getString("n"), o.getString("g"), o.getInt("p"), o.getInt("s"), o.getInt("w"),
                    o.getInt("t"), o.getInt("b"), o.getInt("pr"), o.getString("nd")
                )
            )
        }
        balls = bl
        loadUser()
        if (AppState.clubName.isEmpty() || clubs.none { it.name == AppState.clubName }) {
            AppState.clubName = (clubs.firstOrNull { it.name == "The Extra Mile" } ?: clubs.first()).name
        }
        if (AppState.ballName.isEmpty() || balls.none { it.name == AppState.ballName }) {
            AppState.ballName = balls.first().name
        }
        ready = true
    }

    fun defaultFavs() {
        favs.clear()
        for (n in listOf("Basic", "Marlin", "Navigator", "Quasar", "Titan", "Katana", "Kingmaker", "Golden")) {
            if (balls.any { it.name == n }) favs.add(n)
        }
    }

    fun curClub(): Club = clubs.firstOrNull { it.name == AppState.clubName } ?: clubs.first()
    fun curBall(): Ball = balls.firstOrNull { it.name == AppState.ballName } ?: balls.first()
    fun ballByName(n: String): Ball? = balls.firstOrNull { it.name == n }

    fun levelOf(c: Club): Int = (levels[c.name] ?: 1).coerceIn(1, c.levels.coerceAtLeast(1))
    fun setLevel(c: Club, l: Int) {
        levels[c.name] = l
        saveLevels()
    }

    private fun loadUser() {
        notes = try {
            val a = JSONArray(sp.getString("notes", "[]"))
            val l = mutableListOf<Note>()
            for (i in 0 until a.length()) l.add(Note(a.getString(i)))
            if (l.isEmpty()) mutableListOf(Note("")) else l
        } catch (e: Exception) {
            mutableListOf(Note(""))
        }
        favs.clear()
        try {
            val a = JSONArray(sp.getString("favs", "null"))
            for (i in 0 until a.length()) favs.add(a.getString(i))
        } catch (e: Exception) {
            defaultFavs()
        }
        if (favs.isEmpty() && !sp.contains("favs")) defaultFavs()
        levels.clear()
        try {
            val o = JSONObject(sp.getString("levels", "{}"))
            val it = o.keys()
            while (it.hasNext()) {
                val k = it.next()
                levels[k] = o.getInt(k)
            }
        } catch (e: Exception) {
        }
        try {
            val o = JSONObject(sp.getString("prefs", "{}"))
            p.ballPowerPct = o.optDouble("ballPowerPct", p.ballPowerPct)
            p.windPerPt = o.optDouble("windPerPt", p.windPerPt)
            p.windBase = o.optDouble("windBase", p.windBase)
            p.elevF = o.optDouble("elevF", p.elevF)
            p.headF = o.optDouble("headF", p.headF)
            p.minPct = o.optDouble("minPct", p.minPct)
            p.midPct = o.optDouble("midPct", p.midPct)
            p.autoNote = o.optBoolean("autoNote", p.autoNote)
            p.gridOn = o.optBoolean("gridOn", p.gridOn)
            p.centerLine = o.optBoolean("centerLine", p.centerLine)
            p.markerOn = o.optBoolean("markerOn", p.markerOn)
            p.gridSize = o.optInt("gridSize", p.gridSize)
            p.gridThick = o.optInt("gridThick", p.gridThick)
            p.gridAlpha = o.optInt("gridAlpha", p.gridAlpha)
            p.gridColor = o.optInt("gridColor", p.gridColor)
            p.hudOn = o.optBoolean("hudOn", p.hudOn)
            p.hudSize = o.optInt("hudSize", p.hudSize)
            p.hudPad = o.optBoolean("hudPad", p.hudPad)
            p.hudX = o.optInt("hudX", p.hudX)
            p.hudY = o.optInt("hudY", p.hudY)
            p.panelSize = o.optInt("panelSize", p.panelSize)
            p.gridStyle = o.optInt("gridStyle", p.gridStyle)
            p.gridCx = o.optInt("gridCx", p.gridCx)
            p.gridCy = o.optInt("gridCy", p.gridCy)
            p.bubbleX = o.optInt("bubbleX", p.bubbleX)
            p.bubbleY = o.optInt("bubbleY", p.bubbleY)
            AppState.ballName = o.optString("ballName", "")
            AppState.clubName = o.optString("clubName", "")
        } catch (e: Exception) {
        }
    }

    fun resetCalibration() {
        val d = Prefs()
        p.ballPowerPct = d.ballPowerPct
        p.windPerPt = d.windPerPt
        p.windBase = d.windBase
        p.elevF = d.elevF
        p.headF = d.headF
        p.minPct = d.minPct
        p.midPct = d.midPct
        savePrefs()
    }

    fun saveNotes() {
        val a = JSONArray()
        for (n in notes) a.put(n.body)
        sp.edit().putString("notes", a.toString()).apply()
    }

    fun saveFavs() {
        val a = JSONArray()
        for (n in favs) a.put(n)
        sp.edit().putString("favs", a.toString()).apply()
    }

    fun saveLevels() {
        val o = JSONObject()
        for ((k, v) in levels) o.put(k, v)
        sp.edit().putString("levels", o.toString()).apply()
    }

    fun savePrefs() {
        val o = JSONObject()
        o.put("ballPowerPct", p.ballPowerPct)
        o.put("windPerPt", p.windPerPt)
        o.put("windBase", p.windBase)
        o.put("elevF", p.elevF)
        o.put("headF", p.headF)
        o.put("minPct", p.minPct)
        o.put("midPct", p.midPct)
        o.put("autoNote", p.autoNote)
        o.put("gridOn", p.gridOn)
        o.put("centerLine", p.centerLine)
        o.put("markerOn", p.markerOn)
        o.put("gridSize", p.gridSize)
        o.put("gridThick", p.gridThick)
        o.put("gridAlpha", p.gridAlpha)
        o.put("gridColor", p.gridColor)
        o.put("hudOn", p.hudOn)
        o.put("hudSize", p.hudSize)
        o.put("hudPad", p.hudPad)
        o.put("hudX", p.hudX)
        o.put("hudY", p.hudY)
        o.put("panelSize", p.panelSize)
        o.put("gridStyle", p.gridStyle)
        o.put("gridCx", p.gridCx)
        o.put("gridCy", p.gridCy)
        o.put("bubbleX", p.bubbleX)
        o.put("bubbleY", p.bubbleY)
        o.put("ballName", AppState.ballName)
        o.put("clubName", AppState.clubName)
        sp.edit().putString("prefs", o.toString()).apply()
    }
}
