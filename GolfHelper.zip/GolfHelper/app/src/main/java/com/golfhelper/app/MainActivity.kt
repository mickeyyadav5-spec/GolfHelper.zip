package com.golfhelper.app

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val d = resources.displayMetrics.density
        fun dp(v: Int) = (v * d).toInt()

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setBackgroundColor(Color.parseColor("#101712"))
        root.setPadding(dp(20), dp(40), dp(20), dp(20))

        fun text(s: String, size: Float, color: Int, bold: Boolean = false): TextView {
            val t = TextView(this)
            t.text = s
            t.textSize = size
            t.setTextColor(color)
            if (bold) t.setTypeface(null, Typeface.BOLD)
            return t
        }

        fun button(s: String, color: Int, onClick: () -> Unit): TextView {
            val t = text(s, 16f, Color.WHITE, true)
            t.gravity = Gravity.CENTER
            t.setPadding(dp(16), dp(14), dp(16), dp(14))
            val bg = android.graphics.drawable.GradientDrawable()
            bg.setColor(color)
            bg.cornerRadius = dp(12).toFloat()
            t.background = bg
            t.setOnClickListener { onClick() }
            val lp = LinearLayout.LayoutParams(-1, -2)
            lp.setMargins(0, dp(10), 0, 0)
            t.layoutParams = lp
            return t
        }

        root.addView(text("⛳ Golf Helper", 28f, Color.parseColor("#B2FF59"), true))
        root.addView(text(
            "Golf Clash / Golf Impact ke upar floating helper:\n" +
                "• 500+ balls, saare clubs (level ke saath), ball ke hisaab se wind\n" +
                "• min / mid / max / manual power, elevation\n" +
                "• wind direction dial, grid lines, lens ring\n" +
                "• guide converter (har ball, har club level), notebook auto-fill\n\n" +
                "Ye game ki screen nahi padhta — wind/distance aap khud daalte ho.",
            14f, Color.WHITE
        ))

        root.addView(button("1. Overlay permission do", Color.parseColor("#37474F")) {
            if (Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Permission pehle se mili hui hai", Toast.LENGTH_SHORT).show()
            } else {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
        })

        root.addView(button("2. Helper start karo", Color.parseColor("#2E7D32")) {
            if (!Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "Pehle overlay permission do", Toast.LENGTH_LONG).show()
            } else {
                if (Build.VERSION.SDK_INT >= 33) {
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                }
                startForegroundService(Intent(this, OverlayService::class.java))
                Toast.makeText(this, "Ab game kholo — ⛳ bubble dikhega", Toast.LENGTH_LONG).show()
            }
        })

        root.addView(button("Helper band karo", Color.parseColor("#C62828")) {
            stopService(Intent(this, OverlayService::class.java))
        })

        val sv = ScrollView(this)
        sv.addView(root)
        setContentView(sv)
    }
}
