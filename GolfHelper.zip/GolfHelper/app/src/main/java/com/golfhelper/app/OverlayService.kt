package com.golfhelper.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs
import android.view.WindowManager.LayoutParams as LP

class OverlayService : Service() {

    private lateinit var wm: WindowManager
    private var bubble: View? = null
    private var panel: View? = null
    private var grid: GridView? = null
    private var hud: LinearLayout? = null
    private var hudLens: LensView? = null
    private var hudVal: TextView? = null
    private var hudChip: TextView? = null
    private val padCells = mutableListOf<Pair<TextView, Int>>()
    private var panelLp: LP? = null
    private var scroll: ScrollView? = null
    private var content: LinearLayout? = null
    private var curTab = 0
    private var pickerForGuide = false

    private val TYPE = LP.TYPE_APPLICATION_OVERLAY
    private val PANEL_BG = Color.parseColor("#E6101712")
    private val ACCENT = Color.parseColor("#4CAF50")
    private val ACCENT_L = Color.parseColor("#B2FF59")
    private val GREY = Color.parseColor("#37474F")
    private val MUTED = Color.parseColor("#AEBBAE")
    private val RED = Color.parseColor("#C62828")

    private var calEdits = mutableListOf<EditText>()

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        val n = buildNotification()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
        addGrid()
        addBubble()
        if (Store.p.hudOn) addHud()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == "STOP") {
            stopSelf()
            return START_NOT_STICKY
        }
        return START_STICKY
    }

    override fun onDestroy() {
        try { panel?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { bubble?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { grid?.let { wm.removeView(it) } } catch (e: Exception) {}
        try { hud?.let { wm.removeView(it) } } catch (e: Exception) {}
        panel = null; bubble = null; grid = null; hud = null; hudLens = null
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel("gh", "Golf Helper", NotificationManager.IMPORTANCE_LOW))
        val stop = PendingIntent.getService(
            this, 1, Intent(this, OverlayService::class.java).setAction("STOP"), PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, "gh")
            .setContentTitle("Golf Helper chal raha hai")
            .setContentText("Bubble tap karke panel kholo")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_delete, "Band karo", stop)
            .build()
    }

    // ---------------------------------------------------------------- helpers

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun rounded(color: Int, r: Int, stroke: Int = 0, strokeColor: Int = 0): GradientDrawable {
        val g = GradientDrawable()
        g.setColor(color)
        g.cornerRadius = r.toFloat()
        if (stroke > 0) g.setStroke(stroke, strokeColor)
        return g
    }

    private fun lpw(w: Int, h: Int, l: Int = 0, t: Int = 0, r: Int = 0, b: Int = 0): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h)
        p.setMargins(dp(l), dp(t), dp(r), dp(b))
        return p
    }

    private fun tv(text: String, size: Float = 13f, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = text
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun label(text: String): TextView {
        val t = tv(text, 12f, MUTED, true)
        t.layoutParams = lpw(-2, -2, 0, 8, 0, 2)
        return t
    }

    private fun btn(text: String, color: Int = Color.parseColor("#2E7D32"), onClick: () -> Unit): TextView {
        val t = tv(text, 13f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(dp(12), dp(8), dp(12), dp(8))
        t.background = rounded(color, dp(10))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun edit(hint: String, value: String, numeric: Boolean, signed: Boolean = false): EditText {
        val e = EditText(this)
        e.hint = hint
        e.setText(value)
        e.textSize = 13f
        e.setTextColor(Color.WHITE)
        e.setHintTextColor(Color.parseColor("#77FFFFFF"))
        e.setSingleLine(true)
        e.setPadding(dp(8), dp(6), dp(8), dp(6))
        e.background = rounded(Color.parseColor("#26362B"), dp(8))
        if (numeric) {
            var t = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL
            if (signed) t = t or InputType.TYPE_NUMBER_FLAG_SIGNED
            e.inputType = t
        }
        return e
    }

    private fun hscroll(inner: LinearLayout): HorizontalScrollView {
        val s = HorizontalScrollView(this)
        s.isHorizontalScrollBarEnabled = false
        s.addView(inner)
        return s
    }

    private fun chipRow(items: List<String>, sel: Int, onSel: (Int) -> Unit): HorizontalScrollView {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val chips = mutableListOf<TextView>()
        fun paint(s: Int) {
            for (i in chips.indices) {
                chips[i].background = rounded(if (i == s) ACCENT else GREY, dp(14))
            }
        }
        items.forEachIndexed { i, name ->
            val t = tv(name, 12.5f, Color.WHITE, true)
            t.setPadding(dp(12), dp(7), dp(12), dp(7))
            t.setOnClickListener {
                paint(i)
                onSel(i)
            }
            chips.add(t)
            row.addView(t, lpw(-2, -2, 0, 0, 6, 0))
        }
        paint(sel)
        return hscroll(row)
    }

    private fun clubRow(list: List<Club>, sel: Int, onSel: (Int) -> Unit): HorizontalScrollView {
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val cards = mutableListOf<LinearLayout>()
        fun paint(s: Int) {
            for (i in cards.indices) {
                cards[i].background = rounded(
                    if (i == s) Color.parseColor("#2E7D32") else Color.parseColor("#26362B"),
                    dp(12), if (i == s) dp(2) else 0, ACCENT_L
                )
            }
        }
        list.forEachIndexed { i, club ->
            val card = LinearLayout(this)
            card.orientation = LinearLayout.VERTICAL
            card.gravity = Gravity.CENTER_HORIZONTAL
            card.setPadding(dp(8), dp(6), dp(8), dp(6))
            val icon = ClubIconView(this)
            icon.type = Store.iconType(club.cat)
            icon.color = Store.clubColor(club.name)
            icon.seed = Math.abs(club.name.hashCode())
            icon.bitmap = Store.clubBitmap(this, club.name)
            card.addView(icon, lpw(dp(46), dp(46)))
            val name = tv(club.name, 10.5f, Color.WHITE, true)
            name.gravity = Gravity.CENTER
            card.addView(name, lpw(dp(70), -2))
            card.setOnClickListener {
                paint(i)
                onSel(i)
            }
            cards.add(card)
            row.addView(card, lpw(-2, -2, 0, 0, 6, 0))
        }
        paint(sel)
        return hscroll(row)
    }

    private fun seekRow(
        title: String, min: Int, max: Int, init: Int,
        fmt: (Int) -> String, onChange: (Int) -> Unit
    ): LinearLayout {
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        val head = tv("$title: ${fmt(init)}", 12.5f, Color.WHITE, true)
        val sb = SeekBar(this)
        sb.max = max - min
        sb.progress = (init - min).coerceIn(0, max - min)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                head.text = "$title: ${fmt(p + min)}"
                if (fromUser) onChange(p + min)
            }
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        val minus = btn("−", GREY) {
            sb.progress = (sb.progress - 1).coerceAtLeast(0)
            onChange(sb.progress + min)
        }
        val plus = btn("+", GREY) {
            sb.progress = (sb.progress + 1).coerceAtMost(sb.max)
            onChange(sb.progress + min)
        }
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(minus, lpw(dp(40), -2))
        row.addView(sb, lpw(0, -2).also { it.weight = 1f })
        row.addView(plus, lpw(dp(40), -2))
        box.addView(head)
        box.addView(row)
        box.layoutParams = lpw(-1, -2, 0, 4, 0, 4)
        return box
    }

    private fun toggle(name: String, get: () -> Boolean, set: (Boolean) -> Unit): TextView {
        val t = btn("") {}
        fun paint() {
            t.text = "$name: ${if (get()) "ON" else "OFF"}"
            t.background = rounded(if (get()) Color.parseColor("#2E7D32") else GREY, dp(10))
        }
        t.setOnClickListener {
            set(!get())
            paint()
        }
        paint()
        return t
    }

    private fun currentResult(): Calc.Result {
        val a = AppState
        val c = Store.curClub()
        return Calc.compute(c, Store.curBall(), Store.levelOf(c), a.mode, a.manualPct, a.dist.toDouble(), a.elev.toDouble(), a.wind.toDouble(), a.windDeg.toDouble())
    }

    private fun pushOverlays(r: Calc.Result?) {
        grid?.let {
            it.offsetSq = r?.offset ?: 0.0
            it.showOffset = Store.p.markerOn && r != null && abs(r.offset) >= 0.05
            it.windYd = if (r != null) -r.along * Store.p.headF else 0.0
            it.invalidate()
        }
        hudLens?.let {
            it.angle = AppState.windDeg.toFloat()
            it.invalidate()
        }
        hudVal?.text = "${AppState.wind} mph  ${AppState.windDeg}°"
        for ((cell, ang) in padCells) {
            val on = ang == AppState.windDeg
            cell.background = rounded(if (on) Color.parseColor("#E6FF6D00") else Color.parseColor("#B0000000"), dp(8))
            cell.setTextColor(if (on) Color.WHITE else Color.parseColor("#FF9100"))
        }
        if (r != null) {
            val aimTxt = if (abs(r.offset) < 0.05) "● AIM CENTER"
            else (if (r.offset < 0) "◀ AIM LEFT " else "AIM RIGHT ▶ ") + f1(abs(r.offset))
            val wy = -r.along * Store.p.headF
            val windTxt = if (abs(wy) < 1.0) "● no head/tail wind"
            else (if (wy > 0) "▲ +" else "▼ −") + f0(abs(wy)) + " yd wind"
            hudChip?.text = aimTxt + "\n" + windTxt + "  •  plays " + f0(r.plays) + " yd" +
                "\nMax " + f0(r.max) + "  Mid " + f0(r.mid) + "  Min " + f0(r.min)
        }
    }

    /** called when wind / direction is changed from the floating box */
    private fun syncFromHud() {
        pushOverlays(currentResult())
        if (Store.p.autoNote) autoNote()
        if (panel != null && curTab == 0) {
            val y = scroll?.scrollY ?: 0
            showTab(0)
            scroll?.post { scroll?.scrollTo(0, y) }
        }
    }

    // ---------------------------------------------------------------- notebook helpers

    private fun noteIdx(): Int {
        if (Store.notes.isEmpty()) Store.notes.add(Note(""))
        AppState.notePage = AppState.notePage.coerceIn(0, Store.notes.size - 1)
        return AppState.notePage
    }

    /** keeps one "▶ ..." line at the top of the current notebook page in sync with the Aim tab */
    private fun autoNote() {
        val i = noteIdx()
        val line = Calc.setupLine()
        val body = Store.notes[i].body
        val rest = if (body.startsWith("▶")) body.substringAfter("\n", "") else body
        Store.notes[i].body = if (rest.isEmpty()) line else line + "\n" + rest
        Store.saveNotes()
    }

    private fun appendNote(line: String) {
        val i = noteIdx()
        val body = Store.notes[i].body
        Store.notes[i].body = if (body.isEmpty()) line else body.trimEnd() + "\n" + line
        Store.saveNotes()
    }

    // ---------------------------------------------------------------- overlay windows

    private fun addGrid() {
        val g = GridView(this)
        val lp = LP(
            LP.MATCH_PARENT, LP.MATCH_PARENT, TYPE,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        )
        wm.addView(g, lp)
        grid = g
    }

    private fun mini(text: String, onClick: () -> Unit): TextView {
        val t = tv(text, 12f, Color.WHITE, true)
        t.gravity = Gravity.CENTER
        t.setPadding(0, dp(7), 0, dp(7))
        t.background = rounded(Color.parseColor("#CC37474F"), dp(8))
        t.setOnClickListener { onClick() }
        return t
    }

    private fun addHud() {
        if (hud != null) return
        val s = Store.p
        val dm = resources.displayMetrics
        val lensPx = dp(s.hudSize)
        val width = Math.max(lensPx, dp(184))
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL

        val lp = LP(width, LP.WRAP_CONTENT, TYPE, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = s.hudX
        lp.y = if (s.hudY < 0) (dm.heightPixels * 0.17).toInt() else s.hudY

        val handle = tv("✥ wind (yahan se drag)", 11f, Color.WHITE, true)
        handle.gravity = Gravity.CENTER
        handle.setPadding(dp(8), dp(5), dp(8), dp(5))
        handle.background = rounded(Color.parseColor("#B0000000"), dp(8))
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    try { wm.updateViewLayout(root, lp) } catch (ex: Exception) {}
                }
                MotionEvent.ACTION_UP -> {
                    Store.p.hudX = lp.x
                    Store.p.hudY = lp.y
                    Store.savePrefs()
                }
            }
            true
        }
        root.addView(handle, lpw(-2, -2, 0, 0, 0, 2))

        val lens = LensView(this)
        lens.angle = AppState.windDeg.toFloat()
        lens.onAngle = { AppState.windDeg = it.toInt(); syncFromHud() }
        root.addView(lens, lpw(lensPx, lensPx))

        padCells.clear()
        if (s.hudPad) {
            // 8 arrows = wind direction in one tap (arrow up = tailwind), centre = reset wind to 0
            val glyphs = arrayOf(
                arrayOf("↖" to 315, "↑" to 0, "↗" to 45),
                arrayOf("←" to 270, "⊘" to -1, "→" to 90),
                arrayOf("↙" to 225, "↓" to 180, "↘" to 135)
            )
            val pad = LinearLayout(this)
            pad.orientation = LinearLayout.VERTICAL
            for (rowG in glyphs) {
                val pr = LinearLayout(this)
                for ((g, ang) in rowG) {
                    val cell = tv(g, 22f, Color.parseColor("#FF9100"), true)
                    cell.gravity = Gravity.CENTER
                    cell.setPadding(0, dp(3), 0, dp(3))
                    cell.setOnClickListener {
                        if (ang < 0) {
                            AppState.wind = 0
                            AppState.windDeg = 0
                        } else {
                            AppState.windDeg = ang
                        }
                        syncFromHud()
                    }
                    if (ang >= 0) padCells.add(cell to ang)
                    pr.addView(cell, lpw(0, -2, 1, 1, 1, 1).also { it.weight = 1f })
                }
                pad.addView(pr, lpw(-1, -2))
            }
            root.addView(pad, lpw(-1, -2, 0, 3, 0, 1))
        }

        val valTv = tv("", 12f, Color.WHITE, true)
        valTv.gravity = Gravity.CENTER
        valTv.setPadding(dp(6), dp(5), dp(6), dp(5))
        valTv.background = rounded(Color.parseColor("#B0000000"), dp(8))
        fun bump(d: Int) {
            AppState.wind = (AppState.wind + d).coerceIn(0, 60)
            syncFromHud()
        }
        val row = LinearLayout(this)
        row.gravity = Gravity.CENTER_VERTICAL
        row.addView(mini("−5") { bump(-5) }, lpw(0, -2, 0, 0, 2, 0).also { it.weight = 1f })
        row.addView(mini("−1") { bump(-1) }, lpw(0, -2, 0, 0, 2, 0).also { it.weight = 1f })
        row.addView(valTv, lpw(0, -2, 0, 0, 2, 0).also { it.weight = 2.4f })
        row.addView(mini("+1") { bump(1) }, lpw(0, -2, 0, 0, 2, 0).also { it.weight = 1f })
        row.addView(mini("+5") { bump(5) }, lpw(0, -2).also { it.weight = 1f })
        root.addView(row, lpw(-1, -2, 0, 2, 0, 2))

        val typed = edit("wind number", "", true)
        typed.textSize = 12f
        typed.setPadding(dp(6), dp(4), dp(6), dp(4))
        typed.background = rounded(Color.parseColor("#B0000000"), dp(8))
        val setBtn = mini("Set") {
            val v = typed.text.toString().trim().toDoubleOrNull()
            if (v != null) {
                AppState.wind = Math.round(v).toInt().coerceIn(0, 60)
                typed.setText("")
                syncFromHud()
            }
        }
        val trow = LinearLayout(this)
        trow.gravity = Gravity.CENTER_VERTICAL
        trow.addView(typed, lpw(0, -2, 0, 0, 2, 0).also { it.weight = 2f })
        trow.addView(setBtn, lpw(0, -2).also { it.weight = 1f })
        root.addView(trow, lpw(-1, -2, 0, 0, 0, 2))

        val chip = tv("", 12f, Color.parseColor("#FF8A80"), true)
        chip.gravity = Gravity.CENTER
        chip.setPadding(dp(6), dp(5), dp(6), dp(5))
        chip.background = rounded(Color.parseColor("#B0000000"), dp(8))
        root.addView(chip, lpw(-1, -2))

        // the keyboard needs a focusable window only while the number box is used
        typed.setOnTouchListener { _, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                lp.flags = lp.flags and LP.FLAG_NOT_FOCUSABLE.inv()
                try { wm.updateViewLayout(root, lp) } catch (ex: Exception) {}
            }
            false
        }
        typed.setOnEditorActionListener { _, _, _ ->
            setBtn.performClick()
            lp.flags = lp.flags or LP.FLAG_NOT_FOCUSABLE
            try { wm.updateViewLayout(root, lp) } catch (ex: Exception) {}
            true
        }

        wm.addView(root, lp)
        hud = root
        hudLens = lens
        hudVal = valTv
        hudChip = chip
        pushOverlays(currentResult())
    }

    private fun removeHud() {
        hud?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        hud = null
        hudLens = null
        hudVal = null
        hudChip = null
        padCells.clear()
    }

    private fun addBubble() {
        val b = TextView(this)
        b.text = "⛳"
        b.textSize = 24f
        b.gravity = Gravity.CENTER
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#E62E7D32"))
        bg.setStroke(dp(2), Color.WHITE)
        b.background = bg
        val size = dp(52)
        val lp = LP(size, size, TYPE, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = Store.p.bubbleX
        lp.y = Store.p.bubbleY
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - tx
                    val dy = e.rawY - ty
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = sx + dx.toInt()
                        lp.y = sy + dy.toInt()
                        try { wm.updateViewLayout(b, lp) } catch (ex: Exception) {}
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) togglePanel()
                    Store.p.bubbleX = lp.x
                    Store.p.bubbleY = lp.y
                    Store.savePrefs()
                }
            }
            true
        }
        wm.addView(b, lp)
        bubble = b
    }

    private fun togglePanel() {
        if (panel != null) closePanel() else openPanel()
    }

    private fun closePanel() {
        panel?.let { try { wm.removeView(it) } catch (e: Exception) {} }
        panel = null
        content = null
    }

    private fun openPanel() {
        val dm = resources.displayMetrics
        val ps = Store.p.panelSize.coerceIn(0, 2)
        val w = Math.min(dm.widthPixels - dp(16), dp(intArrayOf(330, 380, 430)[ps]))
        val h = (dm.heightPixels * doubleArrayOf(0.42, 0.58, 0.78)[ps]).toInt()
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.background = rounded(PANEL_BG, dp(16), dp(1), ACCENT)

        val lp = LP(w, h, TYPE, LP.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT)
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = dp(8)
        lp.y = dp(70)
        lp.softInputMode = LP.SOFT_INPUT_ADJUST_RESIZE
        panelLp = lp

        val header = LinearLayout(this)
        header.gravity = Gravity.CENTER_VERTICAL
        header.setPadding(dp(12), dp(8), dp(8), dp(8))
        header.background = rounded(Color.parseColor("#1B5E20"), dp(16))
        header.addView(tv("⛳ Golf Helper", 13f, Color.WHITE, true), lpw(0, -2).also { it.weight = 1f })
        header.addView(btn("S/M/L", GREY) {
            val n = (Store.p.panelSize + 1) % 3
            Store.p.panelSize = n
            Store.savePrefs()
            val d = resources.displayMetrics
            lp.width = Math.min(d.widthPixels - dp(16), dp(intArrayOf(330, 380, 430)[n]))
            lp.height = (d.heightPixels * doubleArrayOf(0.42, 0.58, 0.78)[n]).toInt()
            try { wm.updateViewLayout(root, lp) } catch (ex: Exception) {}
        }, lpw(-2, -2, 0, 0, 6, 0))
        header.addView(btn("—", GREY) { closePanel() }, lpw(dp(40), -2, 0, 0, 6, 0))
        header.addView(btn("✕", RED) { stopSelf() }, lpw(dp(40), -2))
        var sx = 0; var sy = 0; var tx = 0f; var ty = 0f
        header.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = lp.x; sy = lp.y; tx = e.rawX; ty = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = sx + (e.rawX - tx).toInt()
                    lp.y = sy + (e.rawY - ty).toInt()
                    try { wm.updateViewLayout(root, lp) } catch (ex: Exception) {}
                }
            }
            true
        }
        root.addView(header, lpw(-1, -2))

        val tabNames = listOf("Aim", "Guide", "Notes", "Grid", "Data")
        val tabRow = LinearLayout(this)
        tabRow.setPadding(dp(6), dp(6), dp(6), dp(2))
        val tabViews = mutableListOf<TextView>()
        tabNames.forEachIndexed { i, n ->
            val t = btn(n, GREY) {
                showTab(i)
                for (j in tabViews.indices) tabViews[j].background = rounded(if (j == i) ACCENT else GREY, dp(10))
            }
            tabViews.add(t)
            tabRow.addView(t, lpw(0, -2, 2, 0, 2, 0).also { it.weight = 1f })
        }
        root.addView(tabRow, lpw(-1, -2))

        val sv = ScrollView(this)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(dp(12), dp(4), dp(12), dp(16))
        sv.addView(box)
        root.addView(sv, lpw(-1, 0).also { it.weight = 1f })
        scroll = sv

        content = box
        wm.addView(root, lp)
        panel = root
        showTab(if (curTab > 4) 0 else curTab)
        val sel = if (curTab > 4) 0 else curTab
        for (j in tabViews.indices) tabViews[j].background = rounded(if (j == sel) ACCENT else GREY, dp(10))
    }

    private fun showTab(i: Int) {
        curTab = i
        val box = content ?: return
        box.removeAllViews()
        when (i) {
            0 -> buildAim(box)
            1 -> buildGuide(box)
            2 -> buildNotes(box)
            3 -> buildGrid(box)
            4 -> buildData(box)
            else -> buildPicker(box, pickerForGuide)
        }
    }

    private fun openPicker(forGuide: Boolean) {
        pickerForGuide = forGuide
        showTab(5)
    }

    // ---------------------------------------------------------------- BALL PICKER

    private fun ballStatsText(b: Ball): String {
        val sb = StringBuilder("Power ${b.power} • Wind ${b.wind} • Side ${b.side}")
        if (b.top > 0) sb.append(" • Top ${b.top}")
        if (b.back > 0) sb.append(" • Back ${b.back}")
        if (b.prec > 0) sb.append(" • Prec ${b.prec}")
        sb.append(" • Needle ${b.needle}")
        return sb.toString()
    }

    private fun buildPicker(root: LinearLayout, forGuide: Boolean) {
        root.addView(btn("← Wapas", GREY) { showTab(if (forGuide) 1 else 0) })
        root.addView(tv("Naam likh ke khojo. ☆ dabao to ball 'meri balls' me jud jayegi (Aim tab ke shortcut aur guide converter me wahi balls aati hain). Ball par tap = select.", 11.5f, MUTED), lpw(-1, -2, 0, 6, 0, 0))
        val search = edit("Ball ka naam (jaise Titan, Season 80...)", "", false)
        root.addView(search, lpw(-1, -2, 0, 6, 0, 0))
        val favOnly = BooleanArray(1)
        var doFill: () -> Unit = {}
        val ft = toggle("Sirf meri ⭐ balls", { favOnly[0] }, { favOnly[0] = it; doFill() })
        root.addView(ft, lpw(-1, -2, 0, 6, 0, 0))
        val list = LinearLayout(this)
        list.orientation = LinearLayout.VERTICAL
        root.addView(list, lpw(-1, -2, 0, 6, 0, 0))

        fun fill() {
            list.removeAllViews()
            val q = search.text.toString().trim()
            var shown = 0
            var total = 0
            for (b in Store.balls) {
                if (favOnly[0] && !Store.favs.contains(b.name)) continue
                if (q.isNotEmpty() && !b.name.contains(q, true)) continue
                total++
                if (shown >= 50) continue
                shown++
                val row = LinearLayout(this)
                row.gravity = Gravity.CENTER_VERTICAL
                row.background = rounded(Color.parseColor("#1A2A1F"), dp(10))
                row.setPadding(dp(6), dp(4), dp(6), dp(4))
                val star = tv(if (Store.favs.contains(b.name)) "★" else "☆", 22f, Color.parseColor("#FFD54F"), true)
                star.setPadding(dp(8), dp(4), dp(10), dp(4))
                star.setOnClickListener {
                    if (Store.favs.contains(b.name)) Store.favs.remove(b.name) else Store.favs.add(b.name)
                    Store.saveFavs()
                    star.text = if (Store.favs.contains(b.name)) "★" else "☆"
                }
                val info = LinearLayout(this)
                info.orientation = LinearLayout.VERTICAL
                info.addView(tv(b.name + "   (Gen ${b.gen})", 13f, Color.WHITE, true))
                info.addView(tv(ballStatsText(b), 11f, MUTED))
                info.setOnClickListener {
                    if (forGuide) {
                        AppState.guideBallName = b.name
                        showTab(1)
                    } else {
                        AppState.ballName = b.name
                        Store.savePrefs()
                        showTab(0)
                    }
                }
                row.addView(star)
                row.addView(info, lpw(0, -2).also { it.weight = 1f })
                list.addView(row, lpw(-1, -2, 0, 0, 0, 5))
            }
            if (total > shown) {
                list.addView(tv("... aur ${total - shown} balls. Naam likh ke khojo.", 11.5f, MUTED))
            }
            if (total == 0) list.addView(tv("Koi ball nahi mili.", 12f, MUTED))
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) { fill() }
        })
        doFill = { fill() }
        fill()
    }

    // ---------------------------------------------------------------- AIM tab

    private fun buildAim(root: LinearLayout) {
        val a = AppState
        a.catIdx = Store.catKeys.indexOf(Store.curClub().cat).coerceAtLeast(0)

        val big = tv("", 22f, ACCENT_L, true)
        val info = tv("", 12.5f)
        val warn = tv("", 12f, Color.parseColor("#FFB74D"), true)
        val sug = tv("", 12.5f, ACCENT_L)
        val elevInfo = tv("", 12f, MUTED)
        val windInfo = tv("", 12f)
        val ballInfo = tv("", 11.5f, MUTED)
        val clubInfo = tv("", 11.5f, MUTED)
        val dial = WindDialView(this)
        val clubBox = LinearLayout(this)
        clubBox.orientation = LinearLayout.VERTICAL
        val ballBtn = btn("") { openPicker(false) }

        fun refresh() {
            val c = Store.curClub()
            val b = Store.curBall()
            val lv = Store.levelOf(c)
            val r = Calc.compute(c, b, lv, a.mode, a.manualPct, a.dist.toDouble(), a.elev.toDouble(), a.wind.toDouble(), a.windDeg.toDouble())
            ballBtn.text = "Ball: ${b.name}  ▾   (sab balls me khojo)"
            ballInfo.text = ballStatsText(b) + "\nDistance ×${f1(Calc.ballFactor(b))}  •  wind ka asar ×${String.format(java.util.Locale.US, "%.2f", r.windMul)}"
            clubInfo.text = "Lv $lv/${c.levels}  •  Power ${c.pw(lv)} • Acc ${c.accAt(lv)} • Top ${c.topAt(lv)} • Back ${c.backAt(lv)} • Curl ${c.curlAt(lv)} • Guide ${f1(c.guideAt(lv))}"
            big.text = if (abs(r.offset) < 0.05) "AIM  CENTER" else "AIM  " + (if (r.offset < 0) "LEFT  " else "RIGHT  ") + f1(abs(r.offset)) + " sq"
            info.text = "${c.name}  Lv$lv  •  ${b.name}\n" +
                "Max ${f0(r.max)} | Mid ${f0(r.mid)} | Min ${f0(r.min)} yd\n" +
                "Power use ${f0(r.frac * 100)}%  →  ~${f0(r.reach)} yd\n" +
                "Target plays ${f0(r.plays)} yd  (max ka ${f0(r.needPct)}%)"
            val crossTxt = if (abs(r.cross) < 0.05) "no crosswind"
            else "crosswind ${f1(abs(r.cross))} mph → pushes ${if (r.cross > 0) "RIGHT" else "LEFT"}"
            val alongTxt = if (abs(r.along) < 0.05) "no head/tail"
            else "${f1(abs(r.along))} mph ${if (r.along > 0) "TAILWIND" else "HEADWIND"}"
            windInfo.text = "Wind ${a.wind} mph @ ${a.windDeg}°\n$crossTxt\n$alongTxt"
            elevInfo.text = "Elevation ${sgnI(a.elev)}  →  ${sgn(r.elevYd)} yd  (${sgn(r.elevPct)}% power)"
            warn.text = when (r.status) {
                -1 -> "⚠ Bahut kam power lagegi — chhota club lo"
                1 -> "⚠ Distance is club+ball ke max se zyada — bada club lo"
                else -> ""
            }
            val s = Calc.suggest(r.plays, b)
            sug.text = if (s.isEmpty()) "Best club: koi club range me nahi"
            else "Best club: " + s.joinToString("  ›  ") { "${it.name} (Lv${Store.levelOf(it)})" }
            pushOverlays(r)
            if (Store.p.autoNote) autoNote()
        }

        fun buildClubSection() {
            clubBox.removeAllViews()
            clubBox.addView(label("CLUB TYPE"))
            clubBox.addView(chipRow(Store.catNames, a.catIdx) { idx ->
                a.catIdx = idx
                val first = Store.clubs.firstOrNull { it.cat == Store.catKeys[idx] }
                if (first != null) {
                    a.clubName = first.name
                    Store.savePrefs()
                }
                buildClubSection()
                refresh()
            })
            val key = Store.catKeys[a.catIdx.coerceIn(0, Store.catKeys.size - 1)]
            val list = Store.clubs.filter { it.cat == key }
            val cur = Store.curClub()
            val selIdx = list.indexOfFirst { it.name == cur.name }
            clubBox.addView(label("CLUB"))
            clubBox.addView(clubRow(list, selIdx) { i ->
                a.clubName = list[i].name
                Store.savePrefs()
                refresh()
            })
            clubBox.addView(label("CLUB LEVEL (is club ka aapka level)"))
            val c = Store.curClub()
            clubBox.addView(chipRow((1..c.levels).map { "Lv $it" }, Store.levelOf(c) - 1) { i ->
                Store.setLevel(Store.curClub(), i + 1)
                refresh()
            })
        }

        // BALL
        root.addView(label("BALL"))
        root.addView(ballBtn)
        val favList = Store.favs.filter { n -> Store.ballByName(n) != null }
        if (favList.isEmpty()) {
            root.addView(tv("⭐ balls abhi nahi hain. Upar 'Ball' dabao aur ☆ lagao.", 11.5f, MUTED), lpw(-1, -2, 0, 4, 0, 0))
        } else {
            root.addView(chipRow(favList, favList.indexOf(a.ballName)) { i ->
                a.ballName = favList[i]
                Store.savePrefs()
                refresh()
            }, lpw(-2, -2, 0, 6, 0, 0))
        }
        root.addView(ballInfo, lpw(-1, -2, 0, 4, 0, 0))

        // CLUB (rebuilds only its own box)
        root.addView(clubBox)
        buildClubSection()
        root.addView(clubInfo, lpw(-1, -2, 0, 4, 0, 0))

        // POWER MODE
        root.addView(label("POWER  (Min / Mid / Max ya apna %)"))
        val manualBox = seekRow("Manual power", 20, 120, a.manualPct, { "$it%" }) { a.manualPct = it; refresh() }
        manualBox.visibility = if (a.mode == 4) View.VISIBLE else View.GONE
        root.addView(chipRow(listOf("Auto", "Min", "Mid", "Max", "Manual %"), a.mode) { i ->
            a.mode = i
            manualBox.visibility = if (i == 4) View.VISIBLE else View.GONE
            refresh()
        })
        root.addView(manualBox)

        root.addView(seekRow("Distance (pin tak)", 20, 320, a.dist, { "$it yd" }) { a.dist = it; refresh() })
        root.addView(seekRow("Elevation", -40, 40, a.elev, { sgnI(it) }) { a.elev = it; refresh() })
        root.addView(seekRow("Wind", 0, 40, a.wind, { "$it mph" }) { a.wind = it; dial.strength = it; dial.invalidate(); refresh() })

        dial.angle = a.windDeg.toFloat()
        dial.strength = a.wind
        dial.onAngle = { a.windDeg = it.toInt(); refresh() }
        root.addView(label("WIND DIRECTION  (dial par ungli ghumao, game ke arrow jaisa)"))
        val wrow = LinearLayout(this)
        wrow.gravity = Gravity.CENTER_VERTICAL
        wrow.addView(dial, lpw(dp(130), dp(130)))
        windInfo.setPadding(dp(10), 0, 0, 0)
        wrow.addView(windInfo, lpw(0, -2).also { it.weight = 1f })
        root.addView(wrow)

        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.setPadding(dp(12), dp(10), dp(12), dp(10))
        card.background = rounded(Color.parseColor("#1F3324"), dp(12), dp(1), ACCENT)
        card.addView(big)
        card.addView(info)
        card.addView(elevInfo)
        card.addView(warn)
        card.addView(sug)
        card.addView(btn("📓 Notebook me likho", GREY) {
            appendNote(Calc.setupLine())
            Toast.makeText(this, "Notebook me likh diya", Toast.LENGTH_SHORT).show()
        }, lpw(-1, -2, 0, 8, 0, 0))
        root.addView(card, lpw(-1, -2, 0, 10, 0, 0))
        root.addView(tv("1 sq = overlay grid ka ek dibba (Grid tab me size game ke hisaab se set karo). Distance/wind/elevation game me jo dikhe wo aap khud daalte ho.", 11f, MUTED), lpw(-1, -2, 0, 6, 0, 0))
        refresh()
    }

    // ---------------------------------------------------------------- GUIDE tab

    private fun buildGuide(root: LinearLayout) {
        val a = AppState
        if (Store.ballByName(a.guideBallName) == null) a.guideBallName = a.ballName
        root.addView(tv(
            "Premium / tournament ball ki guide yahan likho. Har line: club,wind,offset,elev,level\n" +
                "offset: + = RIGHT aim, − = LEFT aim.  level likhna zaruri nahi.\n" +
                "Jaise:  The Extra Mile,12,-2.5,+5,6", 12f, MUTED
        ))
        root.addView(label("GUIDE KIS BALL KI HAI (reference ball)"))
        root.addView(btn("Ball: ${a.guideBallName}  ▾") { openPicker(true) })
        root.addView(toggle("Har club level ke liye dikhao", { a.guideAllLevels }, { a.guideAllLevels = it }), lpw(-1, -2, 0, 8, 0, 0))
        root.addView(tv("Result me aapki ⭐ balls aati hain (Ball chunne wali list me ☆ lagao).", 11.5f, MUTED), lpw(-1, -2, 0, 4, 0, 0))

        val input = edit("The Extra Mile,12,-2.5,+5,6", a.guideText, false)
        input.setSingleLine(false)
        input.minLines = 5
        input.gravity = Gravity.TOP
        input.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        input.typeface = Typeface.MONOSPACE
        root.addView(input, lpw(-1, -2, 0, 8, 0, 0))

        val out = tv(a.guideOut, 12f, ACCENT_L)
        out.typeface = Typeface.MONOSPACE
        out.setTextIsSelectable(true)

        val buttons = LinearLayout(this)
        buttons.addView(btn("Aim se line jodo") {
            val c = Store.curClub()
            val b = Store.curBall()
            val lv = Store.levelOf(c)
            val r = Calc.compute(c, b, lv, a.mode, a.manualPct, a.dist.toDouble(), a.elev.toDouble(), a.wind.toDouble(), a.windDeg.toDouble())
            val cur = input.text.toString()
            val line = "${c.name},${a.wind},${f1(r.offset)},${a.elev},$lv"
            input.setText(if (cur.isBlank()) line else cur.trimEnd() + "\n" + line)
            a.guideBallName = b.name
            Toast.makeText(this, "Line jud gayi (ball: ${b.name})", Toast.LENGTH_SHORT).show()
        }, lpw(0, -2, 0, 0, 4, 0).also { it.weight = 1f })
        buttons.addView(btn("Convert") {
            a.guideText = input.text.toString()
            val ref = Store.ballByName(a.guideBallName)
            if (ref == null) {
                out.text = "Reference ball chuno."
            } else {
                val targets = Store.favs.mapNotNull { Store.ballByName(it) }
                if (targets.isEmpty()) {
                    a.guideOut = "Pehle kuch balls ko ⭐ karo (Ball chunne wali list me ☆ dabao), phir Convert karo."
                } else {
                    a.guideOut = Calc.convert(a.guideText, ref, a.guideAllLevels, targets)
                }
                out.text = a.guideOut
            }
        }, lpw(0, -2, 4, 0, 0, 0).also { it.weight = 1f })
        root.addView(buttons, lpw(-1, -2, 0, 8, 0, 0))

        val b2 = LinearLayout(this)
        b2.addView(btn("Copy result", GREY) {
            val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            cm.setPrimaryClip(ClipData.newPlainText("guide", a.guideOut))
            Toast.makeText(this, "Copy ho gaya", Toast.LENGTH_SHORT).show()
        }, lpw(0, -2, 0, 0, 3, 0).also { it.weight = 1f })
        b2.addView(btn("Notebook me", GREY) {
            if (a.guideOut.isNotEmpty()) {
                appendNote(a.guideOut)
                Toast.makeText(this, "Notebook me save", Toast.LENGTH_SHORT).show()
            }
        }, lpw(0, -2, 3, 0, 3, 0).also { it.weight = 1f })
        b2.addView(btn("Saaf karo", RED) {
            input.setText("")
            a.guideText = ""
            a.guideOut = ""
            out.text = ""
        }, lpw(0, -2, 3, 0, 0, 0).also { it.weight = 1f })
        root.addView(b2, lpw(-1, -2, 0, 6, 0, 0))

        root.addView(label("RESULT  (har ball: aim + min / mid / max distance + elevation)"))
        root.addView(out)
        root.addView(tv("Note: conversion ball ke 'power' aur 'wind' (0-10) aur Data tab ke calibration se hota hai. Apni real guide ki 1-2 line se match karke calibration theek kar lo.", 11f, MUTED), lpw(-1, -2, 0, 8, 0, 0))
    }

    // ---------------------------------------------------------------- NOTES tab

    private fun buildNotes(root: LinearLayout) {
        val a = AppState
        noteIdx()

        root.addView(chipRow(Store.notes.indices.map { "Page ${it + 1}" }, a.notePage) {
            a.notePage = it
            showTab(2)
        })

        val live = tv(Calc.setupLine(), 11.5f, ACCENT_L, true)
        live.setPadding(dp(8), dp(6), dp(8), dp(6))
        live.background = rounded(Color.parseColor("#1F3324"), dp(8))
        root.addView(live, lpw(-1, -2, 0, 8, 0, 0))
        root.addView(toggle("Auto-fill (wind, elevation, aim notebook me khud)", { Store.p.autoNote }, {
            Store.p.autoNote = it
            Store.savePrefs()
            if (it) {
                autoNote()
                showTab(2)
            }
        }), lpw(-1, -2, 0, 6, 0, 0))

        val ed = RuledEditText(this)
        ed.setText(Store.notes[a.notePage].body)
        ed.setTextColor(Color.parseColor("#3E2F1C"))
        ed.setHintTextColor(Color.parseColor("#998877"))
        ed.hint = "Yahan likho: map, wind, shot, guide..."
        ed.textSize = 15f
        ed.gravity = Gravity.TOP
        ed.minLines = 12
        ed.setPadding(dp(26), dp(10), dp(10), dp(10))
        ed.background = rounded(Color.parseColor("#FFF8E1"), dp(10))
        ed.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        ed.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, st: Int, c: Int, af: Int) {}
            override fun onTextChanged(s: CharSequence?, st: Int, b: Int, c: Int) {}
            override fun afterTextChanged(s: Editable?) {
                val i = a.notePage
                if (i in Store.notes.indices) {
                    Store.notes[i].body = s.toString()
                    Store.saveNotes()
                }
            }
        })
        root.addView(ed, lpw(-1, -2, 0, 8, 0, 0))

        val row = LinearLayout(this)
        row.addView(btn("+ Naya page") {
            Store.notes.add(Note(""))
            a.notePage = Store.notes.size - 1
            Store.saveNotes()
            showTab(2)
        }, lpw(0, -2, 0, 0, 3, 0).also { it.weight = 1f })
        row.addView(btn("Setup likho", GREY) {
            val pos = ed.selectionStart.coerceAtLeast(0)
            ed.text.insert(pos, Calc.setupLine() + "\n")
        }, lpw(0, -2, 3, 0, 3, 0).also { it.weight = 1f })
        row.addView(btn("Delete", RED) {
            if (Store.notes.size > 1) Store.notes.removeAt(a.notePage) else Store.notes[0].body = ""
            a.notePage = 0
            Store.saveNotes()
            showTab(2)
        }, lpw(0, -2, 3, 0, 0, 0).also { it.weight = 1f })
        root.addView(row, lpw(-1, -2, 0, 8, 0, 0))
    }

    // ---------------------------------------------------------------- GRID tab

    private fun buildGrid(root: LinearLayout) {
        val s = Store.p
        fun redraw() {
            Store.savePrefs()
            grid?.invalidate()
        }
        root.addView(tv("Grid game ke upar dikhti hai aur touch ko rokti nahi. Lal dashed line = Aim tab ka suggested aim.", 12f, MUTED))
        root.addView(toggle("Grid", { s.gridOn }, { s.gridOn = it; redraw() }), lpw(-1, -2, 0, 8, 0, 0))
        root.addView(toggle("Beech ki line", { s.centerLine }, { s.centerLine = it; redraw() }), lpw(-1, -2, 0, 6, 0, 0))
        root.addView(toggle("Aim marker (lal line)", { s.markerOn }, {
            s.markerOn = it
            Store.savePrefs()
            pushOverlays(currentResult())
        }), lpw(-1, -2, 0, 6, 0, 0))
        root.addView(btn("Style: ${if (s.gridStyle == 1) "Rings + ticks" else "Dibbe"}  (dabao = badlo)", GREY) {
            s.gridStyle = 1 - s.gridStyle
            redraw()
            showTab(3)
        }, lpw(-1, -2, 0, 6, 0, 0))
        root.addView(seekRow("Grid centre: left-right", 10, 90, s.gridCx, { "$it%" }) { s.gridCx = it; redraw() })
        root.addView(seekRow("Grid centre: upar-neeche", 20, 90, s.gridCy, { "$it%" }) { s.gridCy = it; redraw() })
        root.addView(tv("Grid ka centre apni ball ke upar rakho (Golf Clash me ball neeche hoti hai).", 11f, MUTED))
        root.addView(seekRow("Dibbe ka size", 20, 200, s.gridSize, { "$it px" }) { s.gridSize = it; redraw() })
        root.addView(seekRow("Line motai", 1, 6, s.gridThick, { "$it" }) { s.gridThick = it; redraw() })
        root.addView(seekRow("Transparency (opacity)", 20, 255, s.gridAlpha, { "$it" }) { s.gridAlpha = it; redraw() })

        root.addView(label("GRID COLOR"))
        val colors = listOf("#FFFFFF", "#FFEB3B", "#76FF03", "#00E5FF", "#FF5252", "#000000")
        val crow = LinearLayout(this)
        for (hex in colors) {
            val sw = TextView(this)
            sw.background = rounded(Color.parseColor(hex), dp(8), dp(1), Color.GRAY)
            sw.setOnClickListener { s.gridColor = Color.parseColor(hex); redraw() }
            crow.addView(sw, lpw(dp(40), dp(32), 0, 0, 8, 0))
        }
        root.addView(crow)

        root.addView(label("WIND BOX (game ke left wind arrow ke upar)"))
        root.addView(tv("Ring ko game ke wind arrow ke upar le jao (✥ handle se drag). Ring ko chhuo = direction set, −/+ ya number likh ke Set = wind. Aim chip turant badalta hai.", 12f, MUTED))
        root.addView(toggle("Wind box", { s.hudOn }, {
            s.hudOn = it
            Store.savePrefs()
            if (it) addHud() else removeHud()
        }), lpw(-1, -2, 0, 6, 0, 0))
        root.addView(toggle("8-arrow pad (direction ek tap me)", { s.hudPad }, {
            s.hudPad = it
            Store.savePrefs()
            if (s.hudOn) {
                removeHud()
                addHud()
            }
        }), lpw(-1, -2, 0, 6, 0, 0))
        root.addView(seekRow("Lens size", 80, 220, s.hudSize, { "$it dp" }) {
            s.hudSize = it
            Store.savePrefs()
            if (s.hudOn) {
                removeHud()
                addHud()
            }
        })
    }

    // ---------------------------------------------------------------- DATA tab

    private fun parse(e: EditText, fallback: Double): Double = e.text.toString().trim().toDoubleOrNull() ?: fallback

    private fun commitCal() {
        if (calEdits.size == 7) {
            val p = Store.p
            p.ballPowerPct = parse(calEdits[0], p.ballPowerPct)
            p.windPerPt = parse(calEdits[1], p.windPerPt)
            p.windBase = parse(calEdits[2], p.windBase)
            p.elevF = parse(calEdits[3], p.elevF)
            p.headF = parse(calEdits[4], p.headF)
            p.minPct = parse(calEdits[5], p.minPct).coerceIn(10.0, 100.0)
            p.midPct = parse(calEdits[6], p.midPct).coerceIn(10.0, 100.0)
        }
        Store.savePrefs()
    }

    private fun buildData(root: LinearLayout) {
        calEdits = mutableListOf()
        val p = Store.p
        root.addView(tv("Clubs (${Store.clubs.size}) aur balls (${Store.balls.size}) ka data app ke andar hai. Neeche ke numbers aap game se match karke theek kar sakte ho.", 12f, MUTED))

        fun field(title: String, hint: String, value: String): EditText {
            root.addView(tv(title, 11.5f, MUTED), lpw(-1, -2, 0, 8, 0, 2))
            val e = edit(hint, value, true)
            root.addView(e)
            calEdits.add(e)
            return e
        }
        root.addView(label("CALIBRATION"))
        field("Ball power: har 1 point par kitna % distance badhta hai", "0.5", p.ballPowerPct.toString())
        field("Ball wind: har 1 point par wind kitna kam hota hai (0.05 = 10 point par 50%)", "0.05", p.windPerPt.toString())
        field("Aim: 1 mph crosswind par kitne sq (driver, full power)", "0.55", p.windBase.toString())
        field("Elevation ke har 1 unit par kitne yard", "1.0", p.elevF.toString())
        field("Head/tail wind ke har 1 mph par kitne yard", "1.0", p.headF.toString())
        field("'Min' power = max ka kitna %", "70", f0(p.minPct))
        field("'Mid' power = max ka kitna %", "85", f0(p.midPct))

        val row = LinearLayout(this)
        row.addView(btn("SAVE") {
            commitCal()
            Toast.makeText(this, "Save ho gaya", Toast.LENGTH_SHORT).show()
            showTab(4)
        }, lpw(0, -2, 0, 0, 4, 0).also { it.weight = 1f })
        row.addView(btn("Reset", RED) {
            Store.resetCalibration()
            showTab(4)
        }, lpw(0, -2, 4, 0, 0, 0).also { it.weight = 1f })
        root.addView(row, lpw(-1, -2, 0, 12, 0, 0))

        root.addView(label("MERI ⭐ BALLS (${Store.favs.size})"))
        root.addView(tv(if (Store.favs.isEmpty()) "Koi nahi" else Store.favs.joinToString(", "), 12f, Color.WHITE))
        root.addView(btn("Ball list kholo (⭐ lagao / hatao)", GREY) { openPicker(false) }, lpw(-1, -2, 0, 8, 0, 0))
        root.addView(btn("Sab ⭐ hatao", RED) {
            Store.favs.clear()
            Store.saveFavs()
            showTab(4)
        }, lpw(-1, -2, 0, 6, 0, 0))
    }
}
