package com.golfhelper.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.DashPathEffect
import android.graphics.Paint
import android.graphics.Path
import android.graphics.Rect
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import android.widget.EditText

/** Small drawn picture of a club head (driver / wood / iron / wedge / putter). */
class ClubIconView(ctx: Context) : View(ctx) {
    var type = "iron"
    var color = Color.WHITE
    var bitmap: android.graphics.Bitmap? = null
    var seed = 0
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val bm = bitmap
        if (bm != null) {
            c.drawBitmap(bm, null, RectF(0f, 0f, w, h), p)
            return
        }
        // each club gets its own look: tilted head, different size
        val tilt = ((seed % 5) - 2) * 3f
        c.save()
        c.rotate(tilt, w * 0.5f, h * 0.5f)
        val sc = 0.88f + (seed % 4) * 0.04f
        c.scale(sc, sc, w * 0.5f, h * 0.9f)
        p.color = color
        p.style = Paint.Style.STROKE
        p.strokeWidth = w * 0.07f
        p.strokeCap = Paint.Cap.ROUND
        c.drawLine(w * 0.80f, h * 0.06f, w * 0.40f, h * 0.66f, p)
        p.style = Paint.Style.FILL
        val path = Path()
        when (type) {
            "driver", "wood" -> {
                val bigHead = type == "driver"
                val r = if (bigHead) RectF(w * 0.06f, h * 0.56f, w * 0.60f, h * 0.92f)
                else RectF(w * 0.10f, h * 0.60f, w * 0.58f, h * 0.90f)
                c.drawOval(r, p)
                p.color = Color.parseColor("#55000000")
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f
                c.drawLine(r.left + r.width() * 0.25f, r.centerY(), r.right - r.width() * 0.15f, r.centerY(), p)
            }
            "iron" -> {
                path.moveTo(w * 0.38f, h * 0.62f)
                path.lineTo(w * 0.08f, h * 0.72f)
                path.lineTo(w * 0.10f, h * 0.90f)
                path.lineTo(w * 0.54f, h * 0.88f)
                path.lineTo(w * 0.52f, h * 0.66f)
                path.close()
                c.drawPath(path, p)
                p.color = Color.parseColor("#55000000")
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f
                for (i in 0 until 3) {
                    val y = h * (0.76f + i * 0.04f)
                    c.drawLine(w * 0.16f, y, w * 0.46f, y - h * 0.01f, p)
                }
            }
            "wedge" -> {
                path.moveTo(w * 0.40f, h * 0.62f)
                path.lineTo(w * 0.12f, h * 0.70f)
                path.quadTo(w * 0.04f, h * 0.94f, w * 0.34f, h * 0.93f)
                path.lineTo(w * 0.56f, h * 0.80f)
                path.close()
                c.drawPath(path, p)
                p.color = Color.parseColor("#55000000")
                p.style = Paint.Style.STROKE
                p.strokeWidth = 2f
                for (i in 0 until 3) {
                    val y = h * (0.78f + i * 0.04f)
                    c.drawLine(w * 0.16f, y, w * 0.42f, y - h * 0.01f, p)
                }
            }
            else -> {
                c.drawRect(w * 0.10f, h * 0.70f, w * 0.62f, h * 0.84f, p)
                p.style = Paint.Style.STROKE
                p.strokeWidth = w * 0.07f
                c.drawLine(w * 0.40f, h * 0.66f, w * 0.40f, h * 0.70f, p)
            }
        }
        c.restore()
    }
}

/** Round dial. Touch/drag to set the wind arrow direction. 0 = up, 90 = right, 180 = down, 270 = left. */
class WindDialView(ctx: Context) : View(ctx) {
    var angle = 0f
    var strength = 0
    var onAngle: ((Float) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        val cx = w / 2f
        val cy = h / 2f
        val r = Math.min(w, h) / 2f - 4f
        p.style = Paint.Style.FILL
        p.color = Color.parseColor("#1B2A1B")
        c.drawCircle(cx, cy, r, p)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 3f
        p.color = Color.parseColor("#4CAF50")
        c.drawCircle(cx, cy, r, p)
        p.strokeWidth = 2f
        p.color = Color.parseColor("#88FFFFFF")
        for (i in 0 until 12) {
            val a = Math.toRadians(i * 30.0)
            val s = if (i % 3 == 0) 0.80 else 0.88
            val x1 = (cx + Math.sin(a) * r * s).toFloat()
            val y1 = (cy - Math.cos(a) * r * s).toFloat()
            val x2 = (cx + Math.sin(a) * r).toFloat()
            val y2 = (cy - Math.cos(a) * r).toFloat()
            c.drawLine(x1, y1, x2, y2, p)
        }
        p.style = Paint.Style.FILL
        p.textSize = r * 0.18f
        p.color = Color.parseColor("#AAFFFFFF")
        p.textAlign = Paint.Align.CENTER
        c.drawText("SHOT", cx, cy - r * 0.62f, p)
        val rad = Math.toRadians(angle.toDouble())
        val dx = Math.sin(rad).toFloat()
        val dy = (-Math.cos(rad)).toFloat()
        val tipX = cx + dx * r * 0.74f
        val tipY = cy + dy * r * 0.74f
        val tailX = cx - dx * r * 0.45f
        val tailY = cy - dy * r * 0.45f
        p.color = Color.parseColor("#FFEB3B")
        p.style = Paint.Style.STROKE
        p.strokeWidth = r * 0.10f
        p.strokeCap = Paint.Cap.ROUND
        c.drawLine(tailX, tailY, tipX, tipY, p)
        p.style = Paint.Style.FILL
        val px = -dy
        val py = dx
        val back = r * 0.26f
        val half = r * 0.15f
        val head = Path()
        head.moveTo(tipX + dx * r * 0.08f, tipY + dy * r * 0.08f)
        head.lineTo(tipX - dx * back + px * half, tipY - dy * back + py * half)
        head.lineTo(tipX - dx * back - px * half, tipY - dy * back - py * half)
        head.close()
        c.drawPath(head, p)
        p.color = Color.WHITE
        p.textSize = r * 0.2f
        c.drawText("${strength} mph", cx, cy + r * 0.62f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        val dx = e.x - width / 2f
        val dy = e.y - height / 2f
        var a = Math.toDegrees(Math.atan2(dx.toDouble(), (-dy).toDouble())).toFloat()
        if (a < 0f) a += 360f
        a = (Math.round(a / 5f) * 5f) % 360f
        angle = a
        invalidate()
        onAngle?.invoke(a)
        return true
    }
}

/** Full-screen, touch-through grid that sits on top of the game. Also draws the suggested aim marker. */
class GridView(ctx: Context) : View(ctx) {
    var offsetSq = 0.0
    var showOffset = false
    var windYd = 0.0          // + = play longer (headwind), - = play shorter (tailwind)
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    private fun arrowHead(c: Canvas, x: Float, y: Float, dx: Float, dy: Float, size: Float) {
        // triangle with its tip at (x,y) pointing along (dx,dy)
        val px = -dy
        val py = dx
        val path = Path()
        path.moveTo(x, y)
        path.lineTo(x - dx * size + px * size * 0.55f, y - dy * size + py * size * 0.55f)
        path.lineTo(x - dx * size - px * size * 0.55f, y - dy * size - py * size * 0.55f)
        path.close()
        p.style = Paint.Style.FILL
        c.drawPath(path, p)
    }

    override fun onDraw(c: Canvas) {
        val s = Store.p
        val w = width.toFloat()
        val h = height.toFloat()
        val step = s.gridSize.toFloat().coerceAtLeast(10f)
        val cx = w * s.gridCx / 100f
        val cy = h * s.gridCy / 100f
        p.style = Paint.Style.STROKE
        p.pathEffect = null
        if (s.gridOn) {
            p.strokeWidth = s.gridThick.toFloat()
            p.color = s.gridColor
            p.alpha = s.gridAlpha
            if (s.gridStyle == 1) {
                // rings + crosshair with numbered ticks (like a range-finder)
                val maxR = Math.hypot(Math.max(cx, w - cx).toDouble(), Math.max(cy, h - cy).toDouble()).toFloat()
                var k = 1
                while (k * step <= maxR) {
                    p.strokeWidth = if (k % 5 == 0) s.gridThick + 1.5f else Math.max(1f, s.gridThick / 2f)
                    p.alpha = if (k % 5 == 0) s.gridAlpha else (s.gridAlpha * 0.6f).toInt()
                    c.drawCircle(cx, cy, k * step, p)
                    k++
                }
                p.strokeWidth = s.gridThick.toFloat()
                p.alpha = s.gridAlpha
                c.drawLine(0f, cy, w, cy, p)
                if (s.centerLine) {
                    p.strokeWidth = s.gridThick.toFloat() + 1f
                    p.color = Color.parseColor("#FFEB3B")
                    p.alpha = 230
                }
                c.drawLine(cx, 0f, cx, h, p)
                // ticks + numbers up the centre line and along the horizontal line
                p.color = s.gridColor
                p.alpha = Math.min(255, s.gridAlpha + 60)
                p.strokeWidth = 2f
                p.textAlign = Paint.Align.CENTER
                p.textSize = 22f
                var i = 1
                while (cy - i * step > 0f) {
                    val y = cy - i * step
                    p.style = Paint.Style.STROKE
                    c.drawLine(cx, y, cx + 14f, y, p)
                    p.style = Paint.Style.FILL
                    c.drawText(i.toString(), cx - 16f, y + 8f, p)
                    i++
                }
                i = 1
                while (cx + i * step < w || cx - i * step > 0f) {
                    for (sg in intArrayOf(-1, 1)) {
                        val x = cx + sg * i * step
                        if (x < 0f || x > w) continue
                        p.style = Paint.Style.STROKE
                        c.drawLine(x, cy, x, cy - 14f, p)
                        if (i % 2 == 0) {
                            p.style = Paint.Style.FILL
                            c.drawText(i.toString(), x, cy + 26f, p)
                        }
                    }
                    i++
                }
                p.style = Paint.Style.FILL
                p.color = s.gridColor
                p.alpha = 255
                c.drawCircle(cx, cy, 8f, p)
                p.style = Paint.Style.STROKE
            } else {
                var x = cx
                while (x <= w) {
                    c.drawLine(x, 0f, x, h, p)
                    x += step
                }
                x = cx - step
                while (x >= 0f) {
                    c.drawLine(x, 0f, x, h, p)
                    x -= step
                }
                var y = cy
                while (y <= h) {
                    c.drawLine(0f, y, w, y, p)
                    y += step
                }
                y = cy - step
                while (y >= 0f) {
                    c.drawLine(0f, y, w, y, p)
                    y -= step
                }
                if (s.centerLine) {
                    p.strokeWidth = s.gridThick.toFloat() + 2f
                    p.color = Color.parseColor("#FFEB3B")
                    p.alpha = 220
                    c.drawLine(cx, 0f, cx, h, p)
                }
            }
        }
        // red aim line: only when there really is an offset; runs from the grid centre upward only
        if (showOffset && Math.abs(offsetSq) >= 0.05) {
            val x = cx + (offsetSq * step).toFloat()
            p.style = Paint.Style.STROKE
            p.strokeWidth = s.gridThick.toFloat() + 2f
            p.color = Color.parseColor("#FF5252")
            p.alpha = 235
            p.pathEffect = DashPathEffect(floatArrayOf(22f, 14f), 0f)
            c.drawLine(x, cy, x, 0f, p)
            p.pathEffect = null
            p.style = Paint.Style.FILL
            p.textSize = 30f
            p.textAlign = Paint.Align.CENTER
            val label = "AIM " + sideTxt(offsetSq)
            val tw = p.measureText(label) + 24f
            val lx = x.coerceIn(tw / 2f, w - tw / 2f)
            val ly = Math.max(70f, cy - 6f * step)
            p.color = Color.parseColor("#CC000000")
            c.drawRoundRect(RectF(lx - tw / 2f, ly, lx + tw / 2f, ly + 50f), 14f, 14f, p)
            p.color = Color.parseColor("#FF8A80")
            c.drawText(label, lx, ly + 36f, p)
            // big arrow from the centre line to the red aim line = which way to move your aim
            val ay = cy - 3f * step
            val dir = if (offsetSq < 0) -1f else 1f
            p.style = Paint.Style.STROKE
            p.strokeWidth = 7f
            p.strokeCap = Paint.Cap.ROUND
            p.color = Color.parseColor("#FF5252")
            p.alpha = 240
            c.drawLine(cx, ay, x - dir * 18f, ay, p)
            arrowHead(c, x, ay, dir, 0f, 38f)
        }
        // wind distance adjustment: arrow up = play longer (headwind), down = play shorter (tailwind)
        if (s.markerOn && Math.abs(windYd) >= 1.0) {
            val up = windYd > 0
            val bx = cx + 70f
            val by = cy - 4f * step
            p.style = Paint.Style.STROKE
            p.strokeWidth = 7f
            p.strokeCap = Paint.Cap.ROUND
            p.color = Color.parseColor("#FFB300")
            p.alpha = 240
            val d = if (up) -1f else 1f
            c.drawLine(bx, by - d * 36f, bx, by + d * 14f, p)
            arrowHead(c, bx, by + d * 44f, 0f, d, 34f)
            p.style = Paint.Style.FILL
            p.textSize = 30f
            p.textAlign = Paint.Align.LEFT
            c.drawText((if (up) "+" else "−") + Math.round(Math.abs(windYd)) + " yd", bx + 26f, by + 10f, p)
        }
    }
}

/** Wind lens ring: see-through centre so it can sit over the game's wind arrow. Touch the ring to set the wind direction. */
class LensView(ctx: Context) : View(ctx) {
    var angle = 0f
    var onAngle: ((Float) -> Unit)? = null
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(c: Canvas) {
        val w = width.toFloat()
        val cx = w / 2f
        val cy = height / 2f
        val r = Math.min(w, height.toFloat()) / 2f - 4f
        p.style = Paint.Style.STROKE
        p.strokeWidth = 7f
        p.color = Color.parseColor("#CC00E5FF")
        c.drawCircle(cx, cy, r - 3f, p)
        p.strokeWidth = 3f
        p.color = Color.parseColor("#DDFFFFFF")
        for (i in 0 until 24) {
            val a = Math.toRadians(i * 15.0)
            val len = if (i % 6 == 0) 22f else if (i % 2 == 0) 14f else 8f
            c.drawLine(
                (cx + Math.sin(a) * (r - 8f)).toFloat(), (cy - Math.cos(a) * (r - 8f)).toFloat(),
                (cx + Math.sin(a) * (r - 8f - len)).toFloat(), (cy - Math.cos(a) * (r - 8f - len)).toFloat(), p
            )
        }
        p.style = Paint.Style.FILL
        p.textAlign = Paint.Align.CENTER
        p.textSize = r * 0.17f
        p.color = Color.parseColor("#F0FFFFFF")
        val rr = r - 34f
        val t = p.textSize * 0.35f
        c.drawText("0", cx, cy - rr + t, p)
        c.drawText("180", cx, cy + rr + t, p)
        c.drawText("90", cx + rr, cy + t, p)
        c.drawText("270", cx - rr, cy + t, p)
        // direction arrow (thin, so the game's own arrow stays visible underneath)
        val rad = Math.toRadians(angle.toDouble())
        val dx = Math.sin(rad).toFloat()
        val dy = (-Math.cos(rad)).toFloat()
        val tipX = cx + dx * (r - 12f)
        val tipY = cy + dy * (r - 12f)
        p.style = Paint.Style.STROKE
        p.strokeWidth = 5f
        p.strokeCap = Paint.Cap.ROUND
        p.color = Color.parseColor("#FFEB3B")
        c.drawLine(cx, cy, tipX, tipY, p)
        p.style = Paint.Style.FILL
        val px = -dy
        val py = dx
        val head = Path()
        head.moveTo(tipX + dx * 6f, tipY + dy * 6f)
        head.lineTo(tipX - dx * 26f + px * 13f, tipY - dy * 26f + py * 13f)
        head.lineTo(tipX - dx * 26f - px * 13f, tipY - dy * 26f - py * 13f)
        head.close()
        c.drawPath(head, p)
        c.drawCircle(cx, cy, 5f, p)
    }

    override fun onTouchEvent(e: MotionEvent): Boolean {
        parent?.requestDisallowInterceptTouchEvent(true)
        val dx = e.x - width / 2f
        val dy = e.y - height / 2f
        var a = Math.toDegrees(Math.atan2(dx.toDouble(), (-dy).toDouble())).toFloat()
        if (a < 0f) a += 360f
        a = (Math.round(a / 5f) * 5f) % 360f
        angle = a
        invalidate()
        onAngle?.invoke(a)
        return true
    }
}

/** EditText drawn like a ruled notebook page. */
class RuledEditText(ctx: Context) : EditText(ctx) {
    private val line = Paint().apply {
        color = Color.parseColor("#B8C7E0")
        strokeWidth = 2f
    }
    private val margin = Paint().apply {
        color = Color.parseColor("#E39A9A")
        strokeWidth = 3f
    }

    override fun onDraw(c: Canvas) {
        val r = Rect()
        val base = getLineBounds(0, r)
        var y = base + 8f
        val lh = lineHeight.toFloat()
        while (y < height) {
            c.drawLine(0f, y, width.toFloat(), y, line)
            y += lh
        }
        c.drawLine(paddingLeft - 10f, 0f, paddingLeft - 10f, height.toFloat(), margin)
        super.onDraw(c)
    }
}
