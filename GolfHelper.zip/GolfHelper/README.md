# Golf Helper v1.4 (overlay helper for Golf Clash / Golf Impact)

Game ke upar floating bubble. Ye game ki screen **nahi padhta** — wind, distance, elevation aap khud daalte ho.

## Kya naya hai (v1.4)
- Wind box me 8-arrow pad: ek tap me wind direction (↑ = tailwind, ↓ = headwind), beech ka ⊘ = wind 0. Chip me Max/Mid/Min bhi.

## v1.3
- Aim arrow: grid par lal line tak bada ◀/▶ arrow (aim kis taraf hatana hai).
- Wind distance arrow: ▲ +N yd (headwind, zyada maaro) / ▼ −N yd (tailwind). Wind box ke chip me bhi.

## v1.2
- **Wind box (default ON)**: game ke left wind arrow ke upar rakho. Ring chhuo = direction, −5/−1/+1/+5 ya number likh ke Set = wind. Neeche "AIM L x • N yd" chip.
- **Rings + ticks grid** (range-finder jaisa, numbers ke saath) ya purane dibbe; grid ka centre left-right/upar-neeche set hota hai (Grid tab).
- Lal aim line sirf tab dikhti hai jab aim center se hat ke ho, aur sirf upar ki taraf.
- Panel chhota (S/M/L button), thoda transparent.
- Club icons: har club ka alag rang/shape. Asli picture chahiye to PNG `app/src/main/assets/clubimg/` me rakho (naam: `data/club_image_names.txt`).

## Pehle (v1.1)
- **529 balls** (Power / Wind / Side / Top / Back / Precision / Needle) aur **52 clubs** (har level ke Power, Accuracy,
  Top Spin, Back Spin, Curl, Ball Guide). Data `app/src/main/assets/balls.json` aur `clubs.json` me hai.
- **Ball ke hisaab se wind**: ball ka wind-resistance aur power aim/distance badalta hai.
- **Ball picker**: naam se khojo, ☆ lagao = "meri balls". Aim tab me meri balls ke shortcut.
- **Har club ka apna level** (Lv 1..max), yaad rehta hai.
- **Power**: Auto (distance se) / Min / Mid / Max / Manual %.
- **Guide converter**: `club,wind,offset,elev,level` lines -> har ⭐ ball ke liye aim + min/mid/max distance +
  elevation (yard aur %). "Har club level" ON karo to saare levels ke liye.
- **Notebook**: live setup line + Auto-fill (wind, elevation, aim khud likhta rehta hai).
- Grid, lens ring, bubble pehle jaise.

## Calibration (zaruri)
Ball power/wind ka asar aur wind->aim ka ratio game ka asli formula nahi hai, andaaze ke numbers hain.
Data tab me inhe apni real guide se 1-2 line match karke theek kar lo.

## Data update kaise karein
Naye balls / clubs aane par `data/` folder ki files aur `assets/*.json` update hoti hain (mujhe naya data bhej do).

## APK banane ka tareeka (GitHub Actions, free)
1. GitHub par repository banao aur is folder ki saari files upload karo (`.github/workflows/build.yml` zaroor).
2. Actions tab -> "Build APK" -> run hone do.
3. Artifacts -> GolfHelper-APK download karo, install karo.

## Pehli baar chalane par
App kholo -> "Overlay permission do" -> "Helper start karo" -> game kholo -> ⛳ bubble tap karo.
